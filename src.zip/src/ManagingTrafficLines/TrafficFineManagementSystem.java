package ManagingTrafficLines;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

// Main Execution
public class TrafficFineManagementSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Driver> drivers = new ArrayList<>();
        boolean continueRunning = true;

        while (continueRunning) {
            try {
                // Allow user to input driver details
                System.out.println("Enter the number of drivers:");
                int numOfDrivers = getValidInt(scanner, "Number of drivers");

                for (int i = 0; i < numOfDrivers; i++) {
                    System.out.println("Enter details for Driver " + (i + 1));

                    String name = getValidName(scanner);
                    String licenseNumber = getValidLicenseNumber(scanner);

                    Driver driver = new Driver(name, licenseNumber);
                    drivers.add(driver);

                    // Allow user to input violations for each driver
                    System.out.print("Enter the number of violations for " + name + ": ");
                    int numOfViolations = getValidInt(scanner, "Number of violations");

                    for (int j = 0; j < numOfViolations; j++) {
                        System.out.println("Enter violation " + (j + 1) + " details:");

                        // Get violation type
                        String violationType = getNonEmptyString(scanner, "violation type");

                        // Get violation fine amount
                        System.out.print("Enter fine amount: ");
                        double fineAmount = getValidDouble(scanner);

                        // Create violation and add it to the driver
                        SpecificViolation violation = new SpecificViolation(violationType, fineAmount);
                        driver.addViolation(violation.getFineAmount());
                    }
                }

                // Display Driver Details
                System.out.println("\n--- Driver Details ---");
                for (Driver driver : drivers) {
                    driver.displayDetails();
                    System.out.println();
                }

                // Reset Violations for Driver 1
                if (!drivers.isEmpty()) {
                    System.out.println("Resetting violations for driver: " + drivers.get(0).name);
                    drivers.get(0).resetViolations();
                    drivers.get(0).displayDetails();
                }

                // Ask user if they want to continue or exit
                System.out.print("Do you want to continue? (yes/no): ");
                String userChoice = scanner.nextLine().trim().toLowerCase();

                if (userChoice.equals("no") || userChoice.equals("n")) {
                    continueRunning = false;  // Exit the loop and end the program
                }

            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }

        System.out.println("Thank you for using the Traffic Fine Management System. Goodbye!");
    }

    // Method to get valid integer input
    private static int getValidInt(Scanner scanner, String prompt) {
        int value = -1;
        while (value <= 0) {
            try {
                value = Integer.parseInt(scanner.nextLine().trim());
                if (value <= 0) {
                    System.out.print(prompt + " must be a positive number. Try again: ");
                }
            } catch (NumberFormatException e) {
                System.out.print("Invalid input. Enter a valid number for " + prompt + ": ");
            }
        }
        return value;
    }

    // Method to get valid double input
    private static double getValidDouble(Scanner scanner) {
        double value = -1;
        while (value <= 0) {
            try {
                value = Double.parseDouble(scanner.nextLine().trim());
                if (value <= 0) {
                    System.out.print("Fine amount must be positive. Try again: ");
                }
            } catch (NumberFormatException e) {
                System.out.print("Invalid input. Enter a valid fine amount: ");
            }
        }
        return value;
    }

    // Method to validate name input (alphabets only)
    private static String getValidName(Scanner scanner) {
        String name = "";
        while (true) {
            System.out.print("Enter name (alphabets only): ");
            name = scanner.nextLine().trim();
            if (name.matches("^[A-Za-z ]+$")) {  // Allows alphabets and spaces
                break;
            } else {
                System.out.println("Invalid name. Name must contain alphabets only. Try again.");
            }
        }
        return name;
    }

    // Method to validate license number input (alphanumeric only)
    private static String getValidLicenseNumber(Scanner scanner) {
        String licenseNumber = "";
        while (true) {
            System.out.print("Enter license number (alphanumeric): ");
            licenseNumber = scanner.nextLine().trim();
            if (licenseNumber.matches("^[A-Za-z0-9]+$")) {
                break;
            } else {
                System.out.println("Invalid license number. It must be alphanumeric. Try again.");
            }
        }
        return licenseNumber;
    }

    // Method to ensure string is not empty
    private static String getNonEmptyString(Scanner scanner, String fieldName) {
        String input = "";
        while (input.trim().isEmpty()) {
            System.out.print("Enter " + fieldName + ": ");
            input = scanner.nextLine().trim();
            if (input.isEmpty()) {
                System.out.println(fieldName + " cannot be empty. Try again.");
            }
        }
        return input;
    }
}

// Driver Class
class Driver {
    String name;
    String licenseNumber;
    private double totalFine;

    public Driver(String name, String licenseNumber) {
        this.name = name;
        this.licenseNumber = licenseNumber;
        this.totalFine = 0.0;
    }

    public void addViolation(double fine) {
        this.totalFine += fine;
    }

    public void resetViolations() {
        this.totalFine = 0.0;
    }

    public void displayDetails() {
        System.out.println("Name: " + name);
        System.out.println("License Number: " + licenseNumber);
        System.out.println("Total Fine: $" + totalFine);
    }
}

// Specific Violation Class
class SpecificViolation {
    private String violationType;
    private double fineAmount;

    public SpecificViolation(String violationType, double fineAmount) {
        this.violationType = violationType;
        this.fineAmount = fineAmount;
    }

    public double getFineAmount() {
        return fineAmount;
    }
}
