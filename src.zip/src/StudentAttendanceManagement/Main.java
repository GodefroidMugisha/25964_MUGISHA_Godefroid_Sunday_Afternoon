package StudentAttendanceManagement;

import java.util.*;

class InvalidStudentIdException extends Exception {
    public InvalidStudentIdException(String message) {
        super(message);
    }
}

// Student class to hold student details
class Student {
    private String name;
    private int price;
    private String driver;
    private String plate_number;
    private String seat;

    public Student(String name, int price, String plate_number, String seat, String driver) {
        if (name == null || name.trim().isEmpty() || name.matches(".*\\d.*")) {
            throw new IllegalArgumentException("Name cannot be empty or contain numbers.");
        }
        if (price <= 0 || String.valueOf(price).length() != 4) {
            throw new IllegalArgumentException("ID must be exactly 6 digits.");
        }
        if (!driver.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
            throw new IllegalArgumentException("Invalid email format.");
        }/
        if (seat == null || seat.trim().isEmpty()) {
            throw new IllegalArgumentException("can not be empty.");
        }
        if (plate == null || section.trim().isEmpty()) {
            throw new IllegalArgumentException("Section cannot be empty.");
        }
        this.name = name;
        this.price = price;
        this.plate_number = ;
        this.grade = grade;
        this.section = section;
    }

    // Getters
    public String getName() {
        return name;
    }

    public int getId() {
        return id;
    }

    public String getEmail() {
        return email;
    }

    public String getGrade() {
        return grade;
    }

    public String getSection() {
        return section;
    }
}

// Attendance system to manage students and attendance
class AttendanceSystem {
    private List<Student> students = new ArrayList<>();
    private Map<Integer, Boolean> attendance = new HashMap<>();

    public void addStudent(Student student) {
        students.add(student);
    }

    public boolean studentExists(int studentId) {
        return students.stream().anyMatch(student -> student.getId() == studentId);
    }

    public void markAttendance(int studentId, boolean isPresent) throws InvalidStudentIdException {
        if (!studentExists(studentId)) {
            throw new InvalidStudentIdException("Student ID does not exist.");
        }
        attendance.put(studentId, isPresent);
    }

    public void generateAttendanceReport() {
        for (Student student : students) {
            boolean isPresent = attendance.getOrDefault(student.getId(), false);
            System.out.println("Student: " + student.getName() + " | Attendance: " + (isPresent ? "Present" : "Absent"));
        }
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        AttendanceSystem attendanceSystem = new AttendanceSystem();

        // Add students interactively with validation
        for (int i = 0; i < 3; i++) {
            boolean validInput = false;
            while (!validInput) {
                System.out.println("Enter details for Student " + (i + 1) + ":");

                // Validate Name
                String name = "";
                while (true) {
                    System.out.print("Name: ");
                    name = scanner.nextLine();
                    if (name.matches(".*\\d.*")) {
                        System.out.println("Invalid name. Name cannot contain numbers.");
                    } else if (name.trim().isEmpty()) {
                        System.out.println("Name cannot be empty.");
                    } else {
                        break;
                    }
                }

                // Validate student ID (must be exactly 6 digits)
                int id = -1;
                while (id == -1) {
                    System.out.print("ID (6 digits): ");
                    String idInput = scanner.nextLine();
                    if (idInput.matches("\\d{6}")) {
                        id = Integer.parseInt(idInput);
                    } else {
                        System.out.println("Invalid ID. Please enter a 6-digit numeric ID.");
                    }
                }

                // Validate email format
                String email = "";
                while (true) {
                    System.out.print("Email: ");
                    email = scanner.nextLine();
                    if (email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
                        break; // valid email, exit the loop
                    } else {
                        System.out.println("Invalid email format. Please enter a valid email.");
                    }
                }

                // Validate Grade
                String grade = "";
                while (true) {
                    System.out.print("Grade: ");
                    grade = scanner.nextLine();
                    if (grade.trim().isEmpty()) {
                        System.out.println("Grade cannot be empty.");
                    } else {
                        break;
                    }
                }

                // Validate Section
                String section = "";
                while (true) {
                    System.out.print("Section: ");
                    section = scanner.nextLine();
                    if (section.trim().isEmpty()) {
                        System.out.println("Section cannot be empty.");
                    } else {
                        break;
                    }
                }

                try {
                    // Attempt to create the student object and add it to the system
                    Student student = new Student(name, id, email, grade, section);
                    attendanceSystem.addStudent(student);
                    System.out.println("Student added successfully!\n");
                    validInput = true;  // Exit the loop after successful input
                } catch (IllegalArgumentException e) {
                    System.out.println("Error: " + e.getMessage());
                    // Allow the user to retry on exception
                }
            }
        }

        // Mark attendance for each student interactively
        for (int i = 0; i < 3; i++) {
            boolean validInput = false;
            while (!validInput) {
                System.out.println("Enter attendance for Student " + (i + 1) + ":");

                int studentId = -1;
                // Validate student ID to check if the student exists in the system
                while (studentId == -1) {
                    System.out.print("Enter student ID: ");
                    try {
                        studentId = Integer.parseInt(scanner.nextLine());
                        if (!attendanceSystem.studentExists(studentId)) {
                            throw new InvalidStudentIdException("Student ID does not exist.");
                        }
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid ID. Please enter a numeric ID.");
                    } catch (InvalidStudentIdException e) {
                        System.out.println(e.getMessage());
                    }
                }

                boolean isPresent = false;
                // Validate attendance (true/false)
                while (true) {
                    System.out.print("Is the student present? (true/false): ");
                    String attendanceInput = scanner.nextLine().toLowerCase();
                    if (attendanceInput.equals("true") || attendanceInput.equals("false")) {
                        isPresent = Boolean.parseBoolean(attendanceInput);
                        break; // valid input, exit the loop
                    } else {
                        System.out.println("Invalid input. Please enter true or false.");
                    }
                }

                try {
                    attendanceSystem.markAttendance(studentId, isPresent);
                    System.out.println("Attendance marked successfully!\n");
                    validInput = true;  // Exit the loop after valid input
                } catch (InvalidStudentIdException e) {
                    System.out.println("Error: " + e.getMessage());
                    // Retry if the student ID does not exist
                }
            }
        }

        // Generate attendance report
        System.out.println("\nAttendance Report:");
        attendanceSystem.generateAttendanceReport();

        // Simulate invalid data input (Invalid Email, Invalid Attendance)
        try {
            // Invalid email
            Student invalidStudent = new Student("Invalid", 456789, "invalid-plate_number", "A", "B");
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }

        try {
            // Invalid attendance data
            attendanceSystem.markAttendance(123456, false);  
        } catch (InvalidStudentIdException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
