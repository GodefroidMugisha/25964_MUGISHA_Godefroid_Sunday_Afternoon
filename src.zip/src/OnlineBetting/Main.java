package OnlineBetting;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        RegularUser currentUser = null;
        AdminUser admin = new AdminUser("Ritcho bus ", "please");

        // Adding some games for testing
        Game name = new Game("Rwamagana travel", "Football", 1.5);
        admin.addGame(game1);
        Game game2 = new Game("GAME2", "Basketball", 2.0);
        admin.addGame(game2);

        // User Registration and Login
        System.out.println("Welcome to the Online Betting System");
        System.out.println("Do you want to register a new account? (yes/no)");

        String registerChoice = scanner.nextLine();
        if (registerChoice.equalsIgnoreCase("yes")) {
            String username = getUsername(scanner);
            String password = getPassword(scanner);

            try {
                currentUser = new RegularUser(username, password);
                System.out.println("User registered successfully!");
            } catch (IllegalArgumentException e) {
                System.out.println("Error: " + e.getMessage());
                return; // Stop execution if registration fails
            }
        }

        // User Login
        System.out.println("Enter username to login:");
        String loginUsername = getUsername(scanner);
        System.out.println("Enter password:");
        String loginPassword = getPassword(scanner);

        if (currentUser != null && currentUser.login(loginUsername, loginPassword)) {
            System.out.println("Login successful!");

            // User Menu
            boolean exit = false;
            while (!exit) {
                System.out.println("\nChoose an option:");
                System.out.println("1. Deposit Money");
                System.out.println("2. Place Bet");
                System.out.println("3. View Bet History");
                System.out.println("4. View Balance");
                System.out.println("5. Logout");

                int choice = getValidInt(scanner, 1, 5);

                switch (choice) {
                    case 1:
                        // Deposit Money
                        double amount = getDepositAmount(scanner);
                        try {
                            currentUser.deposit(amount);
                            System.out.println("Deposit successful! New balance: " + currentUser.getBalance());
                        } catch (IllegalArgumentException e) {
                            System.out.println("Error: " + e.getMessage());
                        }
                        break;

                    case 2:
                        // Place Bet
                        System.out.println("Available Games:");
                        System.out.println("1. Football");
                        System.out.println("2. Basketball");
                        int gameChoice = getValidInt(scanner, 1, 2);
                        String gameId = (gameChoice == 1) ? "GAME1" : "GAME2";

                        double betAmount = getBetAmount(scanner);
                        String outcome = getBetOutcome(scanner);

                        Bet bet = new Bet(betAmount, gameId, outcome);
                        try {
                            currentUser.placeBet(bet);
                            System.out.println("Bet placed successfully!");
                        } catch (InsufficientBalanceException | InvalidBetException e) {
                            System.out.println("Error: " + e.getMessage());
                        }
                        break;

                    case 3:
                        // View Bet History
                        System.out.println("Bet History:");
                        List<Bet> betHistory = currentUser.viewBetHistory();
                        if (betHistory.isEmpty()) {
                            System.out.println("No bets placed yet.");
                        } else {
                            for (Bet b : betHistory) {
                                System.out.println(b.getBetDetails());
                            }
                        }
                        break;

                    case 4:
                        // View Balance
                        System.out.println("Current balance: " + currentUser.getBalance());
                        break;

                    case 5:
                        // Logout
                        System.out.println("Logged out successfully!");
                        exit = true;
                        break;

                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }
        } else {
            System.out.println("Invalid login credentials.");
        }

        scanner.close();
    }

    // Method to get valid username input
    private static String getUsername(Scanner scanner) {
        String username;
        while (true) {
            System.out.print("Enter username: ");
            username = scanner.nextLine().trim();
            if (!username.isEmpty() && username.length() >= 5) {
                break;
            }
            System.out.println("Username cannot be empty and must be at least 5 characters long. Please try again.");
        }
        return username;
    }

    // Method to get valid password input
    private static String getPassword(Scanner scanner) {
        String password;
        while (true) {
            System.out.print("Enter password (min 8 characters, must contain letters and numbers): ");
            password = scanner.nextLine();
            if (password.length() >= 8 && password.matches(".*[a-zA-Z]+.*") && password.matches(".*\\d+.*")) {
                break;
            }
            System.out.println("Invalid password. Ensure it's at least 8 characters long and contains both letters and numbers.");
        }
        return password;
    }

    // Method to get valid deposit amount input
    private static double getDepositAmount(Scanner scanner) {
        double amount;
        while (true) {
            System.out.print("Enter amount to deposit: ");
            try {
                amount = Double.parseDouble(scanner.nextLine());
                if (amount <= 0) {
                    System.out.println("Amount must be positive. Please try again.");
                } else {
                    break;
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid amount.");
            }
        }
        return amount;
    }

    // Method to get valid bet amount input
    private static double getBetAmount(Scanner scanner) {
        double betAmount;
        while (true) {
            System.out.print("Enter bet amount: ");
            try {
                betAmount = Double.parseDouble(scanner.nextLine());
                if (betAmount <= 0) {
                    System.out.println("Bet amount must be positive. Please try again.");
                } else {
                    break;
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid bet amount.");
            }
        }
        return betAmount;
    }

    // Method to get valid bet outcome input
    private static String getBetOutcome(Scanner scanner) {
        String outcome;
        while (true) {
            System.out.print("Enter bet outcome (win/loss): ");
            outcome = scanner.nextLine().toLowerCase();
            if (outcome.equals("win") || outcome.equals("loss")) {
                break;
            }
            System.out.println("Invalid outcome. Please enter 'win' or 'loss'.");
        }
        return outcome;
    }

    // Method to get valid integer input within a range
    private static int getValidInt(Scanner scanner, int min, int max) {
        int value;
        while (true) {
            try {
                value = Integer.parseInt(scanner.nextLine());
                if (value >= min && value <= max) {
                    break;
                } else {
                    System.out.println("Please enter a number between " + min + " and " + max + ".");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid number.");
            }
        }
        return value;
    }
}
